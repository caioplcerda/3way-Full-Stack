export default interface IIgreja {
  id?: number;
  nome?: string;
  endereco?: string;
  bairro?: string;
  responsavel?: string;
}